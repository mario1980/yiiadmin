<?php

use yii\db\Schema;
use yii\db\Migration;

class m141107_084935_create_menu_table extends Migration
{
    public function up()
    {

    }

    public function down()
    {
        echo "m141107_084935_create_menu_table cannot be reverted.\n";

        return false;
    }
}
